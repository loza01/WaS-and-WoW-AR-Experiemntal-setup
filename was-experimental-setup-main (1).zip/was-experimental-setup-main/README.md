# Was Experimental Setup

# How to execute?
1 - ```git clone "https://github.com/loza01/was-experimental-setup.git"```
2 - Install dependencies --> ```npm install``` in root directory of the project.
3 - ```nodemone index.js``` if you want automatically to refresh the server when saving new changes or ```node index.js``` if you want to manually refresh the changes. Once this is executed, the server will start listening for new connections.
